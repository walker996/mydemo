package com.bao.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Data
@NoArgsConstructor
@AllArgsConstructor

public class Kcxxb {
    private String kcbm;
    private String admno;
    private String kslx;
    private String jhkszt;
    private String kwkczt;
    private String kjkczt;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date ksrq;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date jsrq;
    private String bz;
}
