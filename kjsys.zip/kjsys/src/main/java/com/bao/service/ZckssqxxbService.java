package com.bao.service;

import com.bao.pojo.Xszmkkcxxb;
import com.bao.pojo.Zckssqxxb;

import java.util.List;

public interface ZckssqxxbService {
    //转出审
    List<Xszmkkcxxb> zhuanchuUser();
    // 改
    int updateZckssq(String admno);
    // 改
    int updatenoZckssq(String admno);
    // 查所有
    List<Xszmkkcxxb> queryAllZckssq();
    //转出审
    List<Zckssqxxb> zzhuanchuUser();
    // 改
    int zupdateZckssq(String admno);
    // 改
    int zupdatenoZckssq(String admno);
    // 查所有
    List<Zckssqxxb> zqueryAllZckssq();

    int addZckssqxxb(Zckssqxxb zckssqxxb);

    Zckssqxxb queryZckssqxxbByAdmno(String admno);

    //转出审
    List<Zckssqxxb> pzhuanchuUser();
    // 改
    int pupdateZckssq(String admno);
    // 查所有
    List<Zckssqxxb> pqueryAllZckssq();
}
