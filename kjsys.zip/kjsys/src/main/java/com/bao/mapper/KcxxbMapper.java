package com.bao.mapper;

import com.bao.pojo.Kcxxb;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface KcxxbMapper {
    int psetCurrentKc(Kcxxb kcxxb);
}
