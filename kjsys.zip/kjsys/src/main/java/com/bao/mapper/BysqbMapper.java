package com.bao.mapper;

import com.bao.pojo.Bysqb;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
@Mapper
public interface BysqbMapper {
    //毕业申请审核
    List<Bysqb> querybysUser();
    // 改
    int updateBysq(String admno);
    // 改
    int updatenoBysq(String admno);
    // 查所有
    List<Bysqb> queryAllUser();
    //毕业申请审核
    List<Bysqb> zquerybysUser();
    // 改
    int zupdateBysq(String admno);
    // 改
    int zupdatenoBysq(String admno);
    // 查所有
    List<Bysqb> zqueryAllUser();

    int addBysqb(Bysqb bysqb);

    Bysqb queryBysqbByAdmno(String admno);

    //毕业申请审核
    List<Bysqb> pquerybysUser();
    // 改
    int pupdateBysq(String admno);
    // 查所有
    List<Bysqb> pqueryAllUser();
}
