package com.bao.controller;

import com.bao.mapper.KcxxbMapper;
import com.bao.pojo.Kcxxb;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class KcxxbController {
    @Autowired
    KcxxbMapper kcxxbMapper;

    @GetMapping("/turn_set_current_kc")
    public String pturnSetCurrentKc() { return "pset_current_kc";}

    @GetMapping("/pset_current_kc")
    public String psetCurrentKc(Kcxxb kcxxb){
        kcxxbMapper.psetCurrentKc(kcxxb);
        return "forward:/pshowKjIndex";}

    @GetMapping("/pshowKjIndex")
    public String pshowKjIndex(){
        return "pkjpost"; }

}
