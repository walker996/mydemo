package com.bao.service.impl;

import com.bao.mapper.BysxxbMapper;
import com.bao.pojo.Bysxxb;
import com.bao.pojo.Kjjbxxb;
import com.bao.service.BysxxbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BysxxbServiceImpl implements BysxxbService {
    @Autowired
    BysxxbMapper bysxxbMapper;

    /*查毕业*/
    @Override
    public List<Bysxxb> querybysUserById() {
        return bysxxbMapper.querybysUserById();
    }
    /*查毕业*/
    @Override
    public List<Bysxxb> zquerybysUserById() {
        return bysxxbMapper.zquerybysUserById();
    }
    @Override
    public int zdeletebys(int id) {
        return bysxxbMapper.zdeletebys(id);
    }

    /*查毕业*/
    @Override
    public List<Bysxxb> pquerybysUserById() {
        return bysxxbMapper.pquerybysUserById();
    }
}
