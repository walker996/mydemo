package com.bao.service.impl;

import com.bao.mapper.XszmkkcxxbMapper;
import com.bao.pojo.Xszmkkcxxb;
import com.bao.service.XszmkkcxxbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class XszmkkcxxbServiceImpl implements XszmkkcxxbService {
    @Autowired
    XszmkkcxxbMapper xszmkkcxxbMapper;
    /*考生免考审核*/
    @Override
    public List<Xszmkkcxxb> oneshen() {
        return xszmkkcxxbMapper.oneshen();
    }

    @Override
    public int updateZmk(String admno) {
        return xszmkkcxxbMapper.updateZmk(admno);
    }

    @Override
    public int updatenoZmk(String admno) {
        return xszmkkcxxbMapper.updatenoZmk(admno);
    }

    @Override
    public List<Xszmkkcxxb> queryAllZmk() {
        return xszmkkcxxbMapper.queryAllZmk();
    }


    /*考生免考审核*/
    @Override
    public List<Xszmkkcxxb> zoneshen() {
        return xszmkkcxxbMapper.zoneshen();
    }

    @Override
    public int zupdateZmk(String admno) {
        return xszmkkcxxbMapper.zupdateZmk(admno);
    }

    @Override
    public int zupdatenoZmk(String admno) {
        return xszmkkcxxbMapper.zupdatenoZmk(admno);
    }

    @Override
    public List<Xszmkkcxxb> zqueryAllZmk() {
        return xszmkkcxxbMapper.zqueryAllZmk();
    }

    @Override
    public int addXszmkkcxxb(Xszmkkcxxb xszmkkcxxb){
        return xszmkkcxxbMapper.addXszmkkcxxb(xszmkkcxxb);
    }
    @Override
    public Xszmkkcxxb queryXszmkkcxxbByAdmno(String admno) {
        return xszmkkcxxbMapper.queryXszmkkcxxbByAdmno(admno);
    }

    @Override
    public List<Xszmkkcxxb> poneshen() {
        return xszmkkcxxbMapper.poneshen();
    }

    @Override
    public int pupdateZmk(String admno) {
        return xszmkkcxxbMapper.pupdateZmk(admno);
    }

    @Override
    public List<Xszmkkcxxb> pqueryAllZmk() {
        return xszmkkcxxbMapper.pqueryAllZmk();
    }

    @Override
    public int psubmitZmk(Xszmkkcxxb xszmkkcxxb) { return xszmkkcxxbMapper.psubmitZmk(xszmkkcxxb);}


}
