package com.bao.service.impl;

import com.bao.mapper.ZckssqxxbMapper;
import com.bao.pojo.Xszmkkcxxb;
import com.bao.pojo.Zckssqxxb;
import com.bao.service.ZckssqxxbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ZckssqxxbServiceImpl implements ZckssqxxbService{
    @Autowired
    ZckssqxxbMapper zckssqxxbMapper;

    /*考生转出手续审核*/
    @Override
    public List<Xszmkkcxxb> zhuanchuUser() {
        return zckssqxxbMapper.zhuanchuUser();
    }

    @Override
    public int updateZckssq(String admno) {
        return zckssqxxbMapper.updateZckssq(admno);
    }

    @Override
    public int updatenoZckssq(String admno) {
        return zckssqxxbMapper.updatenoZckssq(admno);
    }

    @Override
    public List<Xszmkkcxxb> queryAllZckssq() {
        return zckssqxxbMapper.queryAllZckssq();
    }
    /*考生转出手续审核*/
    @Override
    public List<Zckssqxxb> zzhuanchuUser() {
        return zckssqxxbMapper.zzhuanchuUser();
    }

    @Override
    public int zupdateZckssq(String admno) {
        return zckssqxxbMapper.zupdateZckssq(admno);
    }

    @Override
    public int zupdatenoZckssq(String admno) {
        return zckssqxxbMapper.zupdatenoZckssq(admno);
    }

    @Override
    public List<Zckssqxxb> zqueryAllZckssq() {
        return zckssqxxbMapper.zqueryAllZckssq();
    }

    @Override
    public int addZckssqxxb(Zckssqxxb zckssqxxb){
        return zckssqxxbMapper.addZckssqxxb(zckssqxxb);
    }

    @Override
    public Zckssqxxb queryZckssqxxbByAdmno(String admno){
        return zckssqxxbMapper.queryZckssqxxbByAdmno(admno);
    }

    /*考生转出手续审核*/
    @Override
    public List<Zckssqxxb> pzhuanchuUser() {
        return zckssqxxbMapper.pzhuanchuUser();
    }

    @Override
    public int pupdateZckssq(String admno) {
        return zckssqxxbMapper.pupdateZckssq(admno);
    }

    @Override
    public List<Zckssqxxb> pqueryAllZckssq() {
        return zckssqxxbMapper.pqueryAllZckssq();
    }

}
