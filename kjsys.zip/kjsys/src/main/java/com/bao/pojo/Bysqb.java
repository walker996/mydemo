package com.bao.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Bysqb {
    /*毕业申请表   bysqb*/

    private int sqID;/*申请ID*/
    private String admno;
    private String zy;
    private String kcbm;
    private String sname;
    private String sfzh;
    private String xb;
    private String dh;
    private String ds;
    private String xx;
    private String shzt; /*审核状态*/
    private String bz;/*备注*/

}
