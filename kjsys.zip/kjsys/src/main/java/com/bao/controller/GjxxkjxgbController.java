package com.bao.controller;

import com.bao.pojo.Bysqb;
import com.bao.pojo.Gjxxkjxgb;
import com.bao.pojo.Kjjbxxb;
import com.bao.service.GjxxkjxgbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class GjxxkjxgbController {
    @Autowired
    GjxxkjxgbService gjxxkjxgbService;
    //修改审核
    @GetMapping("/mv-key-info")
    public String updateUser(Model model){
        List<Gjxxkjxgb> gjxxkjxgbs = gjxxkjxgbService.updateUser();
        model.addAttribute("gjxxkjxgbs",gjxxkjxgbs);
        return "mv-key-info";
    }

    @GetMapping("/updateGjxx/{admno}")
    public String updateGjxx(@PathVariable("admno")String admno, Model model){
        gjxxkjxgbService.updateGjxx(admno);
        return "forward:/queryAllGjxx";
    }

    @GetMapping("/updatenoGjxx/{admno}")
    public String updatenoGjxx(@PathVariable("admno")String admno, Model model){
        gjxxkjxgbService.updatenoGjxx(admno);
        return "forward:/queryAllGjxx";
    }

    @GetMapping("/queryAllGjxx")
    public String queryAllGjxx(Model model){
        List<Gjxxkjxgb> gjxxkjxgbs = gjxxkjxgbService.queryAllGjxx();
        model.addAttribute("gjxxkjxgbs",gjxxkjxgbs);
        return "mv-key-info";
    }
    @GetMapping("/zmv-key-info")
    public String zupdateUser(Model model){
        List<Gjxxkjxgb> gjxxkjxgbs = gjxxkjxgbService.zupdateUser();
        model.addAttribute("gjxxkjxgbs",gjxxkjxgbs);
        return "zmv-key-info";
    }

    @GetMapping("/zupdateGjxx/{admno}")
    public String zupdateGjxx(@PathVariable("admno")String admno, Model model){
        gjxxkjxgbService.zupdateGjxx(admno);
        return "forward:/zqueryAllGjxx";
    }

    @GetMapping("/zupdatenoGjxx/{admno}")
    public String zupdatenoGjxx(@PathVariable("admno")String admno, Model model){
        gjxxkjxgbService.zupdatenoGjxx(admno);
        return "forward:/zqueryAllGjxx";
    }

    @GetMapping("/zqueryAllGjxx")
    public String zqueryAllGjxx(Model model){
        List<Gjxxkjxgb> gjxxkjxgbs = gjxxkjxgbService.zqueryAllGjxx();
        model.addAttribute("gjxxkjxgbs",gjxxkjxgbs);
        return "zmv-key-info";
    }

    @PostMapping("/informationapply")
    @ResponseBody
    public Map<String, Object> addGjxxkjxgbByAdmno(Gjxxkjxgb gjxxkjxgb){
        //System.out.println(gjxxkjxgb.getAdmno());
        Gjxxkjxgb gjxxkjxgb1 = gjxxkjxgbService.queryGjxxkjxgbByAdmno(gjxxkjxgb.getAdmno());

        if(gjxxkjxgb1!=null){
            Map<String, Object> map = new HashMap<>();
            map.put("result","false");
            return map;
        }else {
            gjxxkjxgbService.addGjxxkjxgbByAdmno(gjxxkjxgb);
            Map<String, Object> map = new HashMap<>();
            map.put("result","success");
            return map;
        }


    }
    @GetMapping("/pfindbyAdmno/{admno}")
    public String pfindbyAdmno(@PathVariable("admno")String admno,Model model){
        Gjxxkjxgb gjxxkjxgb = gjxxkjxgbService.pfindbyAdmno(admno);
        model.addAttribute("gjxxkjxgb", gjxxkjxgb);
        return "pm_key_info_entry";
    }
    @GetMapping("/pm_key_info_entry")
    public String pback(String shzt){
        gjxxkjxgbService.pupdatezt(shzt);
        return "forward:/pqueryAllxg";
    }

    @RequestMapping("/pupdateXg/{admno}")
    public String pupdateXg(Gjxxkjxgb gjxxkjxgb){
        gjxxkjxgbService.pupdateXg(gjxxkjxgb);
        return "forward:/pqueryAllxg";
    }

    @GetMapping("/pqueryAllxg")
    public String pqueryAllxg(Model model){
        List<Gjxxkjxgb> gjxxkjxgbs = gjxxkjxgbService.pquaryAllxg();
        model.addAttribute("gjxxkjxgbs", gjxxkjxgbs);
        return "pkeyentry";
    }
}
