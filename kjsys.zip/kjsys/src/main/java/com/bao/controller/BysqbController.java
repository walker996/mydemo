package com.bao.controller;

import com.bao.pojo.Bysqb;
import com.bao.pojo.Kjjbxxb;
import com.bao.service.BysqbService;
import com.bao.service.KjjbxxbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class BysqbController {
    @Autowired
    BysqbService bysqbService;
    //毕业生审核
    @GetMapping("/graduation-apply-v")
    public String querybysUser(Model model){
        List<Bysqb> bysqbs = bysqbService.querybysUser();
        model.addAttribute("bysqbs",bysqbs);
        return "graduation-apply-v";
    }

    @GetMapping("/updateBysq/{admno}")
    public String updateBysq(@PathVariable("admno")String admno, Model model){
        bysqbService.updateBysq(admno);
        return "forward:/queryAllUser";
    }

    @GetMapping("/updatenoBysq/{admno}")
    public String updatenoBysq(@PathVariable("admno")String admno, Model model){
        bysqbService.updatenoBysq(admno);
        return "forward:/queryAllUser";
    }

    @GetMapping("/queryAllUser")
    public String queryAllUser(Model model){
        List<Bysqb> bysqbs = bysqbService.queryAllUser();
        model.addAttribute("bysqbs",bysqbs);
        return "graduation-apply-v";
    }
    @GetMapping("/zgraduation-apply-v")
    public String zquerybysUser(Model model){
        List<Bysqb> bysqbs = bysqbService.zquerybysUser();
        model.addAttribute("bysqbs",bysqbs);
        return "zgraduation-apply-v";
    }

    @GetMapping("/zupdateBysq/{admno}")
    public String zupdateBysq(@PathVariable("admno")String admno, Model model){
        bysqbService.zupdateBysq(admno);
        return "forward:/zqueryAllUser";
    }

    @GetMapping("/zupdatenoBysq/{admno}")
    public String zupdatenoBysq(@PathVariable("admno")String admno, Model model){
        bysqbService.zupdatenoBysq(admno);
        return "forward:/zqueryAllUser";
    }

    @GetMapping("/zqueryAllUser")
    public String zqueryAllUser(Model model){
        List<Bysqb> bysqbs = bysqbService.zqueryAllUser();
        model.addAttribute("bysqbs",bysqbs);
        return "zgraduation-apply-v";
    }

    @PostMapping("/graduationapply")
    @ResponseBody
    public Map<String, Object> addBysqb(Bysqb bysqb){
        //System.out.println(bysqb);

        Bysqb bysqb1 = bysqbService.queryBysqbByAdmno(bysqb.getAdmno());
        if(bysqb1!=null){
            Map<String, Object> map = new HashMap<>();
            map.put("result","false");
            return map;
        }else{
            bysqbService.addBysqb(bysqb);
            Map<String, Object> map = new HashMap<>();
            map.put("result","success");
            return map;
        }

    }

    @GetMapping("/DiplomaInquire")
    public String DiplomaInquire(Model model, HttpSession httpSession) {
        Kjjbxxb loginkjjbxxb = (Kjjbxxb) httpSession.getAttribute("kjjbxxb");
        Bysqb bysqb = bysqbService.queryBysqbByAdmno(loginkjjbxxb.getAdmno());
        model.addAttribute("bysqb",bysqb);
        return "DiplomaInquire";
    }

    @GetMapping("/pgraduation-apply-v")
    public String pquerybysUser(Model model){
        List<Bysqb> bysqbs = bysqbService.pquerybysUser();
        model.addAttribute("bysqbs",bysqbs);
        return "pgraduation-apply-v";
    }

    @GetMapping("/pupdateBysq/{admno}")
    public String pupdateBysq(@PathVariable("admno")String admno, Model model){
        bysqbService.pupdateBysq(admno);
        return "forward:/pqueryAllUser";
    }

    @GetMapping("/pqueryAllUser")
    public String pqueryAllUser(Model model){
        List<Bysqb> bysqbs = bysqbService.pqueryAllUser();
        model.addAttribute("bysqbs",bysqbs);
        return "pgraduation-apply-v";
    }

}
