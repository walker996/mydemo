package com.bao.controller;

import com.bao.mapper.KjcjxxbMapper;
import com.bao.pojo.Kjcjxxb;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class KjcjxxbController {
    @Autowired
    KjcjxxbMapper kjcjxxbMapper;

    @GetMapping("/turn_score_entry")
    public String pturnScoreEntry(){
        return "pscore_entry";}

    @GetMapping("/pscore_entry")
    public String scoreEntry(Kjcjxxb kjcjxxb){
        kjcjxxbMapper.pscoreEntry(kjcjxxb);
        return "pkjpost";
    }
}
