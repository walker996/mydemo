package com.bao.service;

import com.bao.pojo.Bysxxb;
import com.bao.pojo.Kjjbxxb;

import java.util.List;

public interface BysxxbService {
    // 查毕业生
    List<Bysxxb> querybysUserById();
    // 查毕业生
    List<Bysxxb> zquerybysUserById();
    //删除
    int zdeletebys(int id);
    // 查毕业生
    List<Bysxxb> pquerybysUserById();
}
