package com.bao.service;

import com.bao.pojo.Xszmkkcxxb;

import java.util.List;

public interface XszmkkcxxbService {
    //免考审审核
    List<Xszmkkcxxb> oneshen();
    //改
    int updateZmk(String admno);
    // 改
    int updatenoZmk(String admno);
    // 查所有
    List<Xszmkkcxxb> queryAllZmk();
    //免考审审核
    List<Xszmkkcxxb> zoneshen();
    //改
    int zupdateZmk(String admno);
    // 改
    int zupdatenoZmk(String admno);
    // 查所有
    List<Xszmkkcxxb> zqueryAllZmk();

    int addXszmkkcxxb(Xszmkkcxxb xszmkkcxxb);

    Xszmkkcxxb queryXszmkkcxxbByAdmno(String admno);

    //免考审审核
    List<Xszmkkcxxb> poneshen();
    //改
    int pupdateZmk(String admno);
    // 查所有
    List<Xszmkkcxxb> pqueryAllZmk();

    int psubmitZmk(Xszmkkcxxb xszmkkcxxb);
}
