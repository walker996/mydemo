package com.bao.controller;

import com.bao.pojo.Bysxxb;
import com.bao.pojo.Kjjbxxb;
import com.bao.service.BysxxbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
@Controller

public class BysxxbController {
    @Autowired
    BysxxbService bysxxbService;
    //查毕业生
    @GetMapping("/graduates")
    public String querybysUserById(Model model){
        List<Bysxxb> bysxxbs = bysxxbService.querybysUserById();
        model.addAttribute("bysxxbs",bysxxbs);
        return "graduates";
    }
    @GetMapping("/zgraduates")
    public String zquerybysUserById(Model model){
        List<Bysxxb> bysxxbs = bysxxbService.zquerybysUserById();
        model.addAttribute("bysxxbs",bysxxbs);
        return "zgraduates";
    }
    //删除毕业生信息
    @GetMapping("/zdeletebys/{id}")
    public String zdeletebys(@PathVariable("id")Integer id){
        bysxxbService.zdeletebys(id);
        return "forward:/zgraduates";
    }

    //查毕业生
    @GetMapping("/pgraduates")
    public String pquerybysUserById(Model model){
        List<Bysxxb> bysxxbs = bysxxbService.pquerybysUserById();
        model.addAttribute("bysxxbs",bysxxbs);
        return "pgraduates";
    }
}
