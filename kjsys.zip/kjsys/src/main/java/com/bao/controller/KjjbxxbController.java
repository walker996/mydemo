package com.bao.controller;


import com.bao.pojo.Kjjbxxb;
import com.bao.service.KjjbxxbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class KjjbxxbController {
    @Autowired
    KjjbxxbService kjjbxxbService;

    //查在籍
    @GetMapping("/registered-candidates")
    public String queryUserById(Model model){
        List<Kjjbxxb> kjjbxxbs = kjjbxxbService.queryUserById();
        model.addAttribute("kjjbxxbs",kjjbxxbs);
        return "registered-candidates";
    }




    //打印
    @GetMapping("/print-examination")
    public String dayin(Model model){
        List<Kjjbxxb> kjjbxxbs = kjjbxxbService.dayin();
        model.addAttribute("kjjbxxbs",kjjbxxbs);
        return "print-examination";
    }

    //展示
    @GetMapping("/member-show/{admno}")
    public String show(@PathVariable("admno")String admno, Model model){
        System.out.println(admno);
        Kjjbxxb kjjbxxbs = kjjbxxbService.show(admno);
        model.addAttribute("kjjbxxbs",kjjbxxbs);
        return "member-show";
    }

    //查在籍
    @GetMapping("/zregistered-candidates")
    public String zqueryUserById(Model model){
        List<Kjjbxxb> kjjbxxbs = kjjbxxbService.zqueryUserById();
        model.addAttribute("kjjbxxbs",kjjbxxbs);
        return "zregistered-candidates";
    }
    //删除学籍信息
    @GetMapping("/zdeleteUser/{id}")
    public String zdeleteUser(@PathVariable("id")Integer id){
        kjjbxxbService.zdeleteUser(id);
        return "forward:/zregistered-candidates";
    }


    //打印
    @GetMapping("/zprint-examination")
    public String zdayin(Model model){
        List<Kjjbxxb> kjjbxxbs = kjjbxxbService.zdayin();
        model.addAttribute("kjjbxxbs",kjjbxxbs);
        return "zprint-examination";
    }

    //展示
    @GetMapping("/zmember-show/{admno}")
    public String zshow(@PathVariable("admno")String admno, Model model){
        System.out.println(admno);
        Kjjbxxb kjjbxxbs = kjjbxxbService.zshow(admno);
        model.addAttribute("kjjbxxbs",kjjbxxbs);
        return "zmember-show";
    }

    @GetMapping("/InformationChange")
    public String infomationchange(Model model, HttpSession httpSession) {
        Kjjbxxb loginkjjbxxb = (Kjjbxxb) httpSession.getAttribute("kjjbxxb");
        Kjjbxxb kjjbxxb = kjjbxxbService.queryKjxxByAdmno(loginkjjbxxb.getAdmno());
        model.addAttribute("kjjbxxb",kjjbxxb);
        return "InformationChange";
    }

    @PostMapping("/updatekjjbxxb")
    @ResponseBody
    public Map<String, Object> updatekjjbxxb(Kjjbxxb kjjbxxb){
        kjjbxxbService.updateKjjbxxb(kjjbxxb);
        Map<String, Object> map = new HashMap<>();
        map.put("result","success");
        return map;
    }

    @GetMapping("/KeyInformationChangeApply")
    public String KeyInformationChangeApply(Model model,HttpSession httpSession) {
        Kjjbxxb loginkjjbxxb = (Kjjbxxb) httpSession.getAttribute("kjjbxxb");
        Kjjbxxb kjjbxxb = kjjbxxbService.queryKjxxByAdmno(loginkjjbxxb.getAdmno());
        model.addAttribute("kjjbxxb",kjjbxxb);
        return "KeyInformationChangeApply";
    }

    @GetMapping("/ExemptionApply")
    public String ExemptionApply(Model model,HttpSession httpSession) {
        Kjjbxxb loginkjjbxxb = (Kjjbxxb) httpSession.getAttribute("kjjbxxb");
        Kjjbxxb kjjbxxb = kjjbxxbService.queryKjxxByAdmno(loginkjjbxxb.getAdmno());
        model.addAttribute("kjjbxxb", kjjbxxb);
        return "ExemptionApply";
    }

    @GetMapping("/GraduationApply")
    public String GraduationApply(Model model, HttpSession httpSession) {
        Kjjbxxb loginkjjbxxb = (Kjjbxxb) httpSession.getAttribute("kjjbxxb");
        Kjjbxxb kjjbxxb = kjjbxxbService.queryKjxxByAdmno(loginkjjbxxb.getAdmno());
        model.addAttribute("kjjbxxb", kjjbxxb);
        return "GraduationApply";
    }

    @GetMapping("/StatusOutApply")
    public String StatusOutApply(Model model,HttpSession httpSession) {
        Kjjbxxb loginkjjbxxb = (Kjjbxxb) httpSession.getAttribute("kjjbxxb");
        Kjjbxxb kjjbxxb = kjjbxxbService.queryKjxxByAdmno(loginkjjbxxb.getAdmno());
        model.addAttribute("kjjbxxb", kjjbxxb);
        return "StatusOutApply";
    }

    //查在籍
    @GetMapping("/pregistered-candidates")
    public String pqueryUserById(Model model){
        List<Kjjbxxb> kjjbxxbs = kjjbxxbService.pqueryUserById();
        model.addAttribute("kjjbxxbs",kjjbxxbs);
        return "pregistered-candidates";
    }


    //打印
    @GetMapping("/pprint-examination")
    public String pdayin(Model model){
        List<Kjjbxxb> kjjbxxbs = kjjbxxbService.pdayin();
        model.addAttribute("kjjbxxbs",kjjbxxbs);
        return "pprint-examination";
    }

    //展示
    @GetMapping("/pmember-show/{admno}")
    public String pshow(@PathVariable("admno")Integer admno, Model model){
        System.out.println(admno);
        Kjjbxxb kjjbxxbs = kjjbxxbService.pshow(admno);
        model.addAttribute("kjjbxxbs",kjjbxxbs);
        return "pmember-show";
    }

    //增加
    @GetMapping("/pmember-add")
    public String addUser(Kjjbxxb kjjbxxbs) {
        kjjbxxbService.paddUser(kjjbxxbs);
        return "pmember-add";
    }

}
