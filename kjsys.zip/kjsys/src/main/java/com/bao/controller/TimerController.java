package com.bao.controller;

import com.bao.mapper.TimerMapper;
import com.bao.pojo.Timer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class TimerController {
    @Autowired
    TimerMapper timerMapper;

    @GetMapping("/turn_kj_record_t_set")
    public String turnTset(){return "pkj_record_t_set";}

    @GetMapping("/pkj_record_t_set")
    public String setTime(Timer timer){
        timerMapper.setTime1(timer);
        return ("pkjpost");
    }
}
