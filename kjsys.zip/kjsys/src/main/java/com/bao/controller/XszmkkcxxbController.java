package com.bao.controller;

import com.bao.pojo.Xszmkkcxxb;
import com.bao.service.XszmkkcxxbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class XszmkkcxxbController {
    @Autowired
    XszmkkcxxbService xszmkkcxxbService;

    //免考审核
    @GetMapping("/A-exempt-m")
    public String oneshen(Model model){
        List<Xszmkkcxxb> xszmkkcxxbs = xszmkkcxxbService.oneshen();
        model.addAttribute("xszmkkcxxbs", xszmkkcxxbs);
        return "A-exempt-m";
    }

    @GetMapping("/updateZmk/{admno}")
    public String updateZmk(@PathVariable("admno")String admno, Model model){
        xszmkkcxxbService.updateZmk(admno);
        return "forward:/queryAllZmk";
    }

    @GetMapping("/updatenoZmk/{admno}")
    public String updatenoZmk(@PathVariable("admno")String admno, Model model){
        xszmkkcxxbService.updatenoZmk(admno);
        return "forward:/queryAllZmk";
    }
    @GetMapping("/queryAllZmk")
    public String queryAllZmk(Model model){
        List<Xszmkkcxxb> xszmkkcxxbs = xszmkkcxxbService.queryAllZmk();
        model.addAttribute("xszmkkcxxbs", xszmkkcxxbs);
        return "A-exempt-m";
    }
    //免考审核
    @GetMapping("/zA-exempt-m")
    public String zoneshen(Model model){
        List<Xszmkkcxxb> xszmkkcxxbs = xszmkkcxxbService.zoneshen();
        model.addAttribute("xszmkkcxxbs", xszmkkcxxbs);
        return "zA-exempt-m";
    }

    @GetMapping("/zupdateZmk/{admno}")
    public String zupdateZmk(@PathVariable("admno")String admno, Model model){
        xszmkkcxxbService.zupdateZmk(admno);
        return "forward:/zqueryAllZmk";
    }

    @GetMapping("/zupdatenoZmk/{admno}")
    public String zupdatenoZmk(@PathVariable("admno")String admno, Model model){
        xszmkkcxxbService.zupdatenoZmk(admno);
        return "forward:/zqueryAllZmk";
    }
    @GetMapping("/zqueryAllZmk")
    public String zqueryAllZmk(Model model){
        List<Xszmkkcxxb> xszmkkcxxbs = xszmkkcxxbService.zqueryAllZmk();
        model.addAttribute("xszmkkcxxbs", xszmkkcxxbs);
        return "zA-exempt-m";
    }

    @PostMapping("/exemptionapply")
    @ResponseBody
    public Map<String, Object> addXszmkkcxxb(Xszmkkcxxb xszmkkcxxb){
        //System.out.println(xszmkkcxxb);
        Xszmkkcxxb xszmkkcxxb1 = xszmkkcxxbService.queryXszmkkcxxbByAdmno(xszmkkcxxb.getAdmno());

        if(xszmkkcxxb1 != null){
            Map<String, Object> map = new HashMap<>();
            map.put("result","false");
            return map;
        }else {
            xszmkkcxxbService.addXszmkkcxxb(xszmkkcxxb);
            Map<String, Object> map = new HashMap<>();
            map.put("result", "success");
            return map;
        }

    }

    //免考审核
    @GetMapping("/pA-exempt-m")
    public String poneshen(Model model){
        List<Xszmkkcxxb> xszmkkcxxbs = xszmkkcxxbService.poneshen();
        model.addAttribute("xszmkkcxxbs",xszmkkcxxbs);
        return "pA-exempt-m";
    }

    @GetMapping("/pupdateZmk/{admno}")
    public String pupdateZmk(@PathVariable("admno")String admno, Model model){
        xszmkkcxxbService.pupdateZmk(admno);
        return "forward:/pqueryAllZmk";
    }
    @GetMapping("/psubmitZmk/{admno}")
    public String psubmitZmk(Xszmkkcxxb xszmkkcxxb){
        xszmkkcxxbService.psubmitZmk(xszmkkcxxb);
        return "forward:/pqueryAllZmk";
    }


    @GetMapping("/pqueryAllZmk")
    public String pqueryAllZmk(Model model){
        List<Xszmkkcxxb> xszmkkcxxbs = xszmkkcxxbService.pqueryAllZmk();
        model.addAttribute("xszmkkcxxbs",xszmkkcxxbs);
        return "pA-exempt-m";
    }
}
