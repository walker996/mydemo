package com.bao.mapper;

import com.bao.pojo.Xszmkkcxxb;
import com.bao.pojo.Zckssqxxb;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ZckssqxxbMapper {
    //转出审
    List<Xszmkkcxxb> zhuanchuUser();
    // 改
    int updateZckssq(String admno);
    // 改
    int updatenoZckssq(String admno);
    // 查所有
    List<Xszmkkcxxb> queryAllZckssq();
    //转出审
    List<Zckssqxxb> zzhuanchuUser();
    // 改
    int zupdateZckssq(String admno);
    // 改
    int zupdatenoZckssq(String admno);
    // 查所有
    List<Zckssqxxb> zqueryAllZckssq();

    int addZckssqxxb(Zckssqxxb zckssqxxb);

    Zckssqxxb queryZckssqxxbByAdmno(String admno);

    //转出审
    List<Zckssqxxb> pzhuanchuUser();
    // 改
    int pupdateZckssq(String admno);
    // 查所有
    List<Zckssqxxb> pqueryAllZckssq();
}
