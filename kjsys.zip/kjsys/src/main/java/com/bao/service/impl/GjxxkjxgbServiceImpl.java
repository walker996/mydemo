package com.bao.service.impl;

import com.bao.mapper.GjxxkjxgbMapper;
import com.bao.pojo.Bysqb;
import com.bao.pojo.Gjxxkjxgb;
import com.bao.pojo.Kjjbxxb;
import com.bao.service.GjxxkjxgbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GjxxkjxgbServiceImpl implements GjxxkjxgbService {
       @Autowired
    GjxxkjxgbMapper gjxxkjxgbMapper;

    /*考生关键信息修改审核*/
    @Override
    public List<Gjxxkjxgb> updateUser() {
        return gjxxkjxgbMapper.updateUser();
    }

    @Override
    public int updateGjxx(String admno) {
        return gjxxkjxgbMapper.updateGjxx(admno);
    }

    @Override
    public int updatenoGjxx(String admno) {
        return gjxxkjxgbMapper.updatenoGjxx(admno);
    }

    @Override
    public List<Gjxxkjxgb> queryAllGjxx() {
        return gjxxkjxgbMapper.queryAllGjxx();
    }
    /*考生关键信息修改审核*/
    @Override
    public List<Gjxxkjxgb> zupdateUser() {
        return gjxxkjxgbMapper.zupdateUser();
    }

    @Override
    public int zupdateGjxx(String admno) {
        return gjxxkjxgbMapper.zupdateGjxx(admno);
    }

    @Override
    public int zupdatenoGjxx(String admno) {
        return gjxxkjxgbMapper.zupdatenoGjxx(admno);
    }

    @Override
    public List<Gjxxkjxgb> zqueryAllGjxx() {
        return gjxxkjxgbMapper.zqueryAllGjxx();
    }

    @Override
    public int addGjxxkjxgbByAdmno(Gjxxkjxgb gjxxkjxgb) {
        return gjxxkjxgbMapper.addGjxxkjxgbByAdmno(gjxxkjxgb);
    }

    @Override
    public Gjxxkjxgb queryGjxxkjxgbByAdmno(String admno) {
        return gjxxkjxgbMapper.queryGjxxkjxgbByAdmno(admno);
    }

    @Override
    public Gjxxkjxgb pfindbyAdmno(String admno){
        return gjxxkjxgbMapper.pfindbyAdmno(admno);
    }

    @Override
    public List<Gjxxkjxgb> pquaryAllxg(){
        return gjxxkjxgbMapper.pquaryAllxg();
    }

    @Override
    public int pupdateXg(Gjxxkjxgb gjxxkjxgb) {
        return gjxxkjxgbMapper.pupdateXg(gjxxkjxgb);}

        @Override
    public int pupdatezt(String shzt){
        return gjxxkjxgbMapper.pupdatezt(shzt);
    }
}
