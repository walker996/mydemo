package com.bao.mapper;

import com.bao.pojo.Xszmkkcxxb;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface XszmkkcxxbMapper {
    //免考审审核
    List<Xszmkkcxxb> oneshen();
    // 改
    int updateZmk(String admno);
    // 改
    int updatenoZmk(String admno);
    // 查所有
    List<Xszmkkcxxb> queryAllZmk();
    //免考审审核
    List<Xszmkkcxxb> zoneshen();
    // 改
    int zupdateZmk(String admno);
    // 改
    int zupdatenoZmk(String admno);
    // 查所有
    List<Xszmkkcxxb> zqueryAllZmk();

    //将信息插入到关键信息考籍修改表中
    int addXszmkkcxxb(Xszmkkcxxb xszmkkcxxb);

    Xszmkkcxxb queryXszmkkcxxbByAdmno(String admno);

    //免考审审核
    List<Xszmkkcxxb> poneshen();
    // 改
    int pupdateZmk(String admno);
    // 查所有
    List<Xszmkkcxxb> pqueryAllZmk();

    int psubmitZmk(Xszmkkcxxb xszmkkcxxb);
}
