package com.bao.controller;

import com.bao.pojo.Xszmkkcxxb;
import com.bao.pojo.Zckssqxxb;
import com.bao.service.ZckssqxxbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class ZckssqxxbController {

    @Autowired
    ZckssqxxbService zckssqxxbService;
    //转出审核
    @GetMapping("/transfer-out-v")
    public String zhuanchuUser(Model model){
        List<Xszmkkcxxb> zckssqxxbs = zckssqxxbService.zhuanchuUser();
        model.addAttribute("zckssqxxbs",zckssqxxbs);
        return "transfer-out-v";
    }
    @GetMapping("/updateZckssq/{admno}")
    public String updateZckssq(@PathVariable("admno")String admno, Model model){
        zckssqxxbService.updateZckssq(admno);
        return "forward:/queryAllZckssq";
    }

    @GetMapping("/updatenoZckssq/{admno}")
    public String updatenoZckssq(@PathVariable("admno")String admno, Model model){
        zckssqxxbService.updatenoZckssq(admno);
        return "forward:/queryAllZckssq";
    }

    @GetMapping("/queryAllZckssq")
    public String queryAllZckssq(Model model){
        List<Xszmkkcxxb> zckssqxxbs = zckssqxxbService.queryAllZckssq();
        model.addAttribute("zckssqxxbs",zckssqxxbs);
        return "transfer-out-v";
    }
    @GetMapping("/ztransfer-out-v")
    public String zzhuanchuUser(Model model){
        List<Zckssqxxb> zckssqxxbs = zckssqxxbService.zzhuanchuUser();
        model.addAttribute("zckssqxxbs",zckssqxxbs);
        return "ztransfer-out-v";
    }
    @GetMapping("/zupdateZckssq/{admno}")
    public String zupdateZckssq(@PathVariable("admno")String admno, Model model){
        zckssqxxbService.zupdateZckssq(admno);
        return "forward:/zqueryAllZckssq";
    }

    @GetMapping("/zupdatenoZckssq/{admno}")
    public String zupdatenoZckssq(@PathVariable("admno")String admno, Model model){
        zckssqxxbService.zupdatenoZckssq(admno);
        return "forward:/zqueryAllZckssq";
    }

    @GetMapping("/zqueryAllZckssq")
    public String zqueryAllZckssq(Model model){
        List<Zckssqxxb> zckssqxxbs = zckssqxxbService.zqueryAllZckssq();
        model.addAttribute("zckssqxxbs",zckssqxxbs);
        return "ztransfer-out-v";
    }

    @PostMapping("/outapply")
    @ResponseBody
    public Map<String, Object> addZckssqxxb(Zckssqxxb zckssqxxb) {
        Zckssqxxb zckssqxxb1 = zckssqxxbService.queryZckssqxxbByAdmno(zckssqxxb.getAdmno());

        if (zckssqxxb1 != null) {
            Map<String, Object> map = new HashMap<>();
            map.put("result", "false");
            return map;
        } else {
            zckssqxxbService.addZckssqxxb(zckssqxxb);
            Map<String, Object> map = new HashMap<>();
            map.put("result", "success");
            return map;
        }
    }
    //转出审核
    @GetMapping("/ptransfer-out-v")
    public String pzhuanchuUser(Model model){
        List<Zckssqxxb> zckssqxxbs = zckssqxxbService.pzhuanchuUser();
        model.addAttribute("zckssqxxbs",zckssqxxbs);
        return "ptransfer-out-v";
    }
    @GetMapping("/pupdateZckssq/{admno}")
    public String pupdateZckssq(@PathVariable("admno")String admno, Model model){
        zckssqxxbService.pupdateZckssq(admno);
        return "forward:/pqueryAllZckssq";
    }


    @GetMapping("/pqueryAllZckssq")
    public String pqueryAllZckssq(Model model){
        List<Zckssqxxb> zckssqxxbs = zckssqxxbService.pqueryAllZckssq();
        model.addAttribute("zckssqxxbs",zckssqxxbs);
        return "ptransfer-out-v";
    }
}
