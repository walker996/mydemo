package com.bao.service.impl;

import com.bao.mapper.BysqbMapper;
import com.bao.pojo.Bysqb;
import com.bao.pojo.Kjjbxxb;
import com.bao.service.BysqbService;
import com.bao.service.GjxxkjxgbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class BysqbServiceImpl  implements BysqbService {
    @Autowired
    BysqbMapper bysqbMapper;

    /*毕业生申请审核*/
    @Override
    public List<Bysqb> querybysUser() {
        return bysqbMapper.querybysUser();
    }
    @Override
    public int updateBysq(String admno) {
        return bysqbMapper.updateBysq(admno);
    }

    @Override
    public int updatenoBysq(String admno) {
        return bysqbMapper.updatenoBysq(admno);
    }

    @Override
    public List<Bysqb> queryAllUser() {
        return bysqbMapper.queryAllUser();
    }
    /*毕业生申请审核*/
    @Override
    public List<Bysqb> zquerybysUser() {
        return bysqbMapper.zquerybysUser();
    }
    @Override
    public int zupdateBysq(String admno) {
        return bysqbMapper.zupdateBysq(admno);
    }

    @Override
    public int zupdatenoBysq(String admno) {
        return bysqbMapper.zupdatenoBysq(admno);
    }

    @Override
    public List<Bysqb> zqueryAllUser() {
        return bysqbMapper.zqueryAllUser();
    }

    @Override
    public int addBysqb(Bysqb bysqb){
        return bysqbMapper.addBysqb(bysqb);
    }

    @Override
    public Bysqb queryBysqbByAdmno(String admno){
        return bysqbMapper.queryBysqbByAdmno(admno);
    }

    @Override
    public List<Bysqb> pquerybysUser() {
        return bysqbMapper.pquerybysUser();
    }
    @Override
    public int pupdateBysq(String admno) {
        return bysqbMapper.pupdateBysq(admno);
    }

    @Override
    public List<Bysqb> pqueryAllUser() {
        return bysqbMapper.pqueryAllUser();
    }
}
