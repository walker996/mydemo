package com.bao.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Xszmkkcxxb {

    /*转免考申请  xszmkkcxxb*/
    private String mkkc; /*免考课程*/
    private String kcbm; /*考次编码*/
    private String mklx; /*免考类型编码*/
    private String cj; /*成绩*/
    private String ds; /*地市*/
    private String xx;/*学校*/
    private String mkmsxx; /*免考描述信息*/
    private String shzt;  /*审核状态*/
    private String admno;
}
