package com.bao.mapper;

import com.bao.pojo.Kjcjxxb;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface KjcjxxbMapper {
    int pscoreEntry(Kjcjxxb kjcjxxb);
}
