package com.bao.service;

import com.bao.pojo.Gjxxkjxgb;
import com.bao.pojo.Kjjbxxb;

import java.util.List;

public interface GjxxkjxgbService {
    // 关键信息审核
    List<Gjxxkjxgb> updateUser();
    // 改
    int updateGjxx(String admno);
    // 改
    int updatenoGjxx(String admno);
    // 查所有
    List<Gjxxkjxgb> queryAllGjxx();
    // 关键信息审核
    List<Gjxxkjxgb> zupdateUser();
    // 改
    int zupdateGjxx(String admno);
    // 改
    int zupdatenoGjxx(String admno);
    // 查所有
    List<Gjxxkjxgb> zqueryAllGjxx();

    int addGjxxkjxgbByAdmno(Gjxxkjxgb gjxxkjxgb);

    Gjxxkjxgb queryGjxxkjxgbByAdmno(String admno);

    Gjxxkjxgb pfindbyAdmno(String admno);

    List<Gjxxkjxgb> pquaryAllxg();

    int pupdateXg(Gjxxkjxgb gjxxkjxgb);

    int pupdatezt(String shzt);
}
