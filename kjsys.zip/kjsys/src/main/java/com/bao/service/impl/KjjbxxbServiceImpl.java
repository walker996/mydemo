package com.bao.service.impl;

import com.bao.mapper.KjjbxxbMapper;
import com.bao.pojo.Kjjbxxb;
import com.bao.service.KjjbxxbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class KjjbxxbServiceImpl implements KjjbxxbService {
        @Autowired
    KjjbxxbMapper kjjbxxbMapper;

    /*查在籍*/
    @Override
    public List<Kjjbxxb> queryUserById() {
        return kjjbxxbMapper.queryUserById();
    }



    /*查所有*/
    @Override
    public List<Kjjbxxb> queryAllUser() {
        return kjjbxxbMapper.queryAllUser();
    }
    /*登录*/
    @Override
    public Kjjbxxb login(Kjjbxxb user) {
        Kjjbxxb loginUser = kjjbxxbMapper.login(user);
        return loginUser;
    }


    /*考籍表打印*/
    @Override
    public List<Kjjbxxb> dayin() {
        return kjjbxxbMapper.dayin();
    }

    /*展示信息*/
    @Override
    public Kjjbxxb show(String admno) {
        return kjjbxxbMapper.show(admno);
    }

    /*查在籍*/
    @Override
    public List<Kjjbxxb> zqueryUserById() {
        return kjjbxxbMapper.zqueryUserById();
    }



    /*查所有*/
    @Override
    public List<Kjjbxxb> zqueryAllUser() {
        return kjjbxxbMapper.zqueryAllUser();
    }

    //删除学籍
    @Override
    public int zdeleteUser(int id) {
        return kjjbxxbMapper.zdeleteUser(id);
    }
    /*考籍表打印*/
    @Override
    public List<Kjjbxxb> zdayin() {
        return kjjbxxbMapper.zdayin();
    }

    /*展示信息*/
    @Override
    public Kjjbxxb zshow(String admno) {
        return kjjbxxbMapper.zshow(admno);
    }

    public Kjjbxxb queryKjxxByAdmno(String admno) {
        return kjjbxxbMapper.queryKjxxByAdmno(admno);
    }

    public int updateKjjbxxb(Kjjbxxb kjjbxxb) {
        return kjjbxxbMapper.updateKjjbxxb(kjjbxxb);
    }

    public Kjjbxxb verityByAdmno(Kjjbxxb kjjbxxb){
        return kjjbxxbMapper.verityByAdmno(kjjbxxb);
    }

    /*查在籍*/
    @Override
    public List<Kjjbxxb> pqueryUserById() {
        return kjjbxxbMapper.pqueryUserById();
    }

    /*查所有*/
    @Override
    public List<Kjjbxxb> pqueryAllUser() {
        return kjjbxxbMapper.pqueryAllUser();
    }
    /*登录*/
    @Override
    public Kjjbxxb plogin(Kjjbxxb user) {
        Kjjbxxb loginUser = kjjbxxbMapper.plogin(user);
        return loginUser;
    }


    /*考籍表打印*/
    @Override
    public List<Kjjbxxb> pdayin() {
        return kjjbxxbMapper.pdayin();
    }

    /*展示信息*/
    @Override
    public Kjjbxxb pshow(int admno) {
        return kjjbxxbMapper.pshow(admno);
    }

    /*增加*/
    @Override
    public int paddUser(Kjjbxxb user) {
        return kjjbxxbMapper.paddUser(user);
    }


}
