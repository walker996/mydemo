package com.bao.controller;


import com.bao.pojo.Kjjbxxb;
import com.bao.service.KjjbxxbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

@Controller
public class LoginController {

    @Autowired
    KjjbxxbService kjjbxxbService;

   @RequestMapping ("/sindex")
    public String sindex(){
        return "sindex";
    }

    @RequestMapping ("/xindex")
    public String xindex(){
        return "xindex";
    }

    @GetMapping("/")
    public String index(){
        return "login";
    }

    @GetMapping("/pkjpost")
    public String pindex(){
        return "pkjpost";
    }

    @PostMapping("/verity")
    @ResponseBody
    public Map<String, Object> verity(Kjjbxxb kjjbxxb, HttpSession session){
        Kjjbxxb kjjbxxb1 = kjjbxxbService.verityByAdmno(kjjbxxb);
        Map<String, Object> map = new HashMap<>();
        if (kjjbxxb1 == null){
            //登录失败，用户名或密码错误
            map.put("result","false");
            return map;
        }else {
            map.put("result","success");
            session.setAttribute("kjjbxxb",kjjbxxb1);
            return map;
        }
    }

    @GetMapping("/KSindex")
    public String KSindex(){
        return "KSindex";
    }


}
