package com.bao.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

@Controller
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Zckssqxxb {
    /*转出考生申请信息*/
    private String admno; /*准考证号*/
    private String sname;
    private String sqID;  /*申请ID*/
    private String zcyy;  /*转出原因*/
    private String zcbm;  /*转出编码*/
    private String zrzy;  /*转入专业*/
    private String shzt;  /*审核状态*/
}