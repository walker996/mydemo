package com.bao.mapper;

import com.bao.pojo.Kjjbxxb;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface KjjbxxbMapper {
    // 查在籍考生
    List<Kjjbxxb> queryUserById();
    // 查所有
    List<Kjjbxxb> queryAllUser();

    // 登录
    Kjjbxxb login(Kjjbxxb kjjbxxb);


    //打印
    List<Kjjbxxb> dayin();

    //展示
    Kjjbxxb show(String admno);
    // 查在籍考生
    List<Kjjbxxb> zqueryUserById();
    // 查所有
    List<Kjjbxxb> zqueryAllUser();



    int zdeleteUser(Integer id);
    //打印
    List<Kjjbxxb> zdayin();

    //展示
    Kjjbxxb zshow(String admno);

    Kjjbxxb queryKjxxByAdmno(String admno);

    int updateKjjbxxb(Kjjbxxb kjjbxxb);

    Kjjbxxb verityByAdmno(Kjjbxxb kjjbxxb);

    // 查在籍考生
    List<Kjjbxxb> pqueryUserById();
    // 查所有
    List<Kjjbxxb> pqueryAllUser();
    // 登录
    Kjjbxxb plogin(Kjjbxxb kjjbxxb);
    //增加
    int paddUser(Kjjbxxb kjjbxxb);

    //打印
    List<Kjjbxxb> pdayin();
    //展示
    Kjjbxxb pshow(int admno);
}
