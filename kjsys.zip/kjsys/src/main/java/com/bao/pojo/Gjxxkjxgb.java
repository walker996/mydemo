package com.bao.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Gjxxkjxgb {

    /*关键信息考籍更改表 gjxxkjxgb*/
    private String admno;
    private String kcbm;/*考次编码*/
    private String ds;/*地市*/
    private String xx;/*学校*/
    private String blzt;/*办理状态*/
    private String zy;/*专业*/
    private String sfzh;/*身份证号*/
    private String sname;/*姓名*/
    private String csrq;/*出生日期*/
    private String xjzt; /*学籍状态*/
    private String shzt;/*审核状态*/

}
