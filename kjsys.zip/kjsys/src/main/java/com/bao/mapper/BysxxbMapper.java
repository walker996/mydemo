package com.bao.mapper;

import com.bao.pojo.Bysxxb;
import com.bao.pojo.Kjjbxxb;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface BysxxbMapper {
    // 查毕业生
   List<Bysxxb> querybysUserById();
    // 查毕业生
    List<Bysxxb> zquerybysUserById();
    int zdeletebys(Integer id);

    // 查毕业生
    List<Bysxxb> pquerybysUserById();
}
